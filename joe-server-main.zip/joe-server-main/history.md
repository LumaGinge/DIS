1  ls
    
2  sudo apt-get install -y curl
    
3  curl -fsSL https://deb.nodesource.com/setup_18.x -o nodesource_setup.sh
    
4  sudo -E bash nodesource_setup.sh
    
5  node -v
    
6  sudo apt-get install -y nodejs
    
7  node -v
    
8  git pull https://github.com/miwnKEA/joe-server.git

9  ls

10  git pull https://github.com/miwnKEA/joe-server.git

11  history

12  git clone https://github.com/miwnKEA/joe-server.git

13  ls

14  cd joe-server/

15  ls

16  npm install

17  node app.js 

18  ls
   
19  cd public/
   
20  ls
   
21  cd scripts/
   
22  ls
   
23  sudo nano index.js 
   
24  cd ..
   
25  node app.js 
   
26  cd ..
   
27  rm -rf joe-server
   
28  ls
   
32  history
   
33  git clone https://github.com/miwnKEA/joe-server.git
   
34  cd joe-server/

35  npm install

36  node app.js 

37  clear

38  cd ..

39  clear

40  ls

41  rm -rf joe-server/

42  clear

43  git clone https://github.com/miwnKEA/joe-server.git

44  cd joe-server/

45  npm install

46  node app.js

47  cd ..

48  rm -rf joe-server/

49  git clone https://github.com/miwnKEA/joe-server.git && cd joe-server

50  ls

51  npm install

52  node app.js 

53  cd ..

54  rm -rf joe-server/

55  ls

56  git clone https://github.com/miwnKEA/joe-server.git && cd joe-server

57  npm install

58  node app.js 

59  cd ..

60  rm -rf joe-server/

61  git clone https://github.com/miwnKEA/joe-server.git && cd joe-server

62  npm install

63  node app.js 

64  cd ..

65  rm -rf joe-server/

66  git clone https://github.com/miwnKEA/joe-server.git && cd joe-server

67  npm install

68  node app.js

69  npm install pm2

70  sudo npm install pm2@latest -g

71  pm2 start server.js

72  pm2 start app.js

73  pm2 startup systemd

74  pm2 save

75  sudo env PATH=$PATH:/usr/bin /usr/lib/node_modules/pm2/bin/pm2 startup systemd -u root --hp /home/root

76  pm2 save

77  sudo systemctl start pm2-root

78  systemctl status pm2-root

79  history

80  cd ..

81  sudo apt update

82  sudo ap install nginx

83  sudo apt install nginx

84  sudo nginx -v

85  systemctl status nginx

86  sudo ufw app list

87  sudo ufw allow 'Nginx HTTP'

88  sudo ufw enable

89  sudo ufw status

90  sudo nginx -t

91  sudo nano /etc/nginx/sites-available/default

92  sudo nginx -t

93  sudo systemctl restart nginx

94  pm2 list

95  history

96  sudo nano /etc/nginx/sites-available/default

97  history
